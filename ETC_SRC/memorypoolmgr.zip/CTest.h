#ifndef _C_TEST_H_
#define _C_TEST_H_

//#include "CMemoryPool.h"
#include "CCustumMemoryAllocator.h"
#include <vector>

using namespace std;





//-------------------------------------------------------
//	Macro�� ���� �ʴ� ���
//--------------------------------------------------------
#if 0
class CTest
{
	//DECLARE_MEMORYPOOL
	public:
		
		//--------------------------------------------
		//	new ������
		//--------------------------------------------
		void*	operator new( size_t BlockSize )
		{
			if( !m_pMemoryPool )
			{
				m_pMemoryPool = new CMemoryPool;
			}
			return m_pMemoryPool->Allocate( BlockSize );
		}

		//--------------------------------------------
		//	delete ������
		//--------------------------------------------
		void	operator delete( void *pToBlockDelete, size_t BlockSize )
		{
			m_pMemoryPool->Delocate( pToBlockDelete, BlockSize  );
		}
	public:
		CTest(){}
		~CTest(){}

	protected:
		int		m_Var1;
		int		m_Var2;
		int		m_Var3;
	
	protected:
		static	CMemoryPool *m_pMemoryPool;

};

CMemoryPool *CTest::m_pMemoryPool = 0;

#endif

//--------------------------------------------------------
//	*Test Class
//--------------------------------------------------------
class CTestA
{
	DECLARE_MEMORYPOOL;
	
	public:

	public:
		CTestA(){}
		~CTestA(){}

	protected:
		int		m_Var1;
		int		m_Var2;
		int		m_Var3;
	
	protected:
		//static	CMemoryPool *m_pMemoryPool;

};

IMPLEMENATION_MEMORYPOOL( CTestA );



//-------------------------------------------
//
//-------------------------------------------
class CTestB
{
	DECLARE_MEMORYPOOL;
	
	public:

	public:
		CTestB(){}
		~CTestB(){}

	protected:
		int		m_Var1;
		int		m_Var2;
	
	protected:
		//static	CMemoryPool *m_pMemoryPool;

};

IMPLEMENATION_MEMORYPOOL( CTestB );


#endif //_C_TEST_H_