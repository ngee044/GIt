#ifndef _C_CUSTUM_ALLOCATOR_H_
#define _C_CUSTUM_ALLOCATOR_H_

class CMemoryPool;

class CCustumMemoryAllocator
{
	public:
		void	SetMemoryPool( CMemoryPool *pMemoryPool );
		void*	operator new( size_t BlockSize );
		void	operator delete( void *pToBlockDelete );
	protected:

		CMemoryPool *m_pMemoryPool;
};


#endif // _C_CUSTUM_ALLOCATOR_H_