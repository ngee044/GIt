// MemoryPoolMgr.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.

#include "CTest.h"

int main(int argc, char* argv[])
{
	//----------------------------------
	//
	//----------------------------------
	CTestA *pObjectA	= new CTestA;

	int Size = static_cast< int >(sizeof( *pObjectA ) );
	printf("Memory Size is...%d\n",Size );


	CTestA *pObjectA_1	= new CTestA;

	Size = static_cast< int >(sizeof( *pObjectA_1 ) );
	printf("Memory Size is...%d\n",Size );

	CTestA *pObjectA_2	= new CTestA;

	Size = static_cast< int >(sizeof( *pObjectA_2 ) );
	printf("Memory Size is...%d\n",Size );
	
	delete pObjectA;
	delete pObjectA_1;
	delete pObjectA_2;
	

	//----------------------------------
	//
	//----------------------------------
	CTestB *pObjectB	= new CTestB;

	Size = static_cast< int >(sizeof( *pObjectB ) );
	printf("Memory Size is...%d\n",Size );

	delete pObjectB;

	return 0;
}

