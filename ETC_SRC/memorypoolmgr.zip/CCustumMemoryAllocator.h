#ifndef _C_CUSTUM_ALLOCATOR_H_
#define _C_CUSTUM_ALLOCATOR_H_

#include "CMemoryPool.h"
#include <vector>

using namespace std;

//--------------------------------------------
//	Macro Define
//---------------------------------------------
#define IMPLEMENATION_MEMORYPOOL( ClassName )\
CMemoryPool *ClassName::m_pMemoryPool = 0;\

//->START DECLARE_MEMORYPOOL
#define DECLARE_MEMORYPOOL \
	public:	\
		void	*operator new( size_t BlockSize )\
		{ \
			if( !m_pMemoryPool ) \
			{ \
				m_pMemoryPool = new CMemoryPool; \
			} \
			return m_pMemoryPool->Allocate( BlockSize ); \
		} \
		void	operator delete( void *pToBlockDelete, size_t BlockSize ) \
		{ \
			m_pMemoryPool->Delocate( pToBlockDelete, BlockSize  ); \
		} \
	protected: \
		static	CMemoryPool *m_pMemoryPool; \

//<- END DECLARE_MEMORYPOOL



#endif // _C_CUSTUM_ALLOCATOR_H_